# My Bure Khurd — फोन से APK बनाने का आसान तरीका

यह project GitHub Actions के जरिए cloud में Android APK बना सकता है। फोन में Android Studio की जरूरत नहीं होगी।

## कदम
1. GitHub.com पर login करें और नया repository बनाएं।
2. इस पूरे project की files upload करें।
3. GitHub में **Actions** खोलें।
4. **Build My Bure Khurd APK** चुनें।
5. **Run workflow** दबाएं।
6. Build पूरा होने पर workflow run खोलें।
7. **Artifacts** में `My-Bure-Khurd-debug-APK` डाउनलोड करें।
8. ZIP खोलकर `app-debug.apk` फोन में install करें।

यह debug APK testing/install के लिए है। Play Store पर डालने के लिए बाद में signed release build बनाना होगा।
