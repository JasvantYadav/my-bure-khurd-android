# My Bure Khurd — Android APK Project

यह Android WebView app मौजूदा Netlify पर चल रहे My Bure Khurd ऐप को एक वास्तविक Android ऐप के रूप में खोलता है।

## ऐप
- नाम: My Bure Khurd
- Package: com.myburekhurd.app
- URL: https://t-4939d9.netlify.app/index.html
- Portrait mode
- JavaScript + DOM storage enabled (Supabase login/data के लिए आवश्यक)

## APK बनाना
Android Studio में project खोलें और:
Build → Build Bundle(s) / APK(s) → Build APK(s)

Debug APK `app/build/outputs/apk/debug/` में बनेगा। Android documentation के अनुसार debug APK debug key से signed होता है और सीधे install किया जा सकता है।

## महत्वपूर्ण
यह wrapper मौजूदा cloud app को खोलता है; इसलिए website/Netlify और Supabase उपलब्ध रहना चाहिए।
Release/Play Store के लिए अलग release signing key बनानी होगी।
